import { Request,Response } from "express";
import User, { IUser } from "../models/User";
import jwt from "jsonwebtoken"
import bcrypt from 'bcryptjs';
import { IEvent } from "../models/Event";


export const registerUser = async(
   req:Request,
   res:Response
):Promise<void> =>{
   try {
      const {username,email,password} = req.body;
      
      const existingUser = await User.findOne({email:email});
      if(existingUser)
      {
         res.status(400).json({message:"User already exists"});
         return;
      }
        const hashedPassword = await bcrypt.hash(password,10);

        const newUser:IUser = new User({
         username,email,password:hashedPassword
        });
        await newUser.save();
        res.status(201).json({message:"User registered successfully"})

   } catch (error:any) {
    console.log(error.message);
    res.status(500).json({error: error.message});
   }
}



export const loginUser = async(req:Request,res:Response):Promise<void> =>{
   try {
    const {email,password} = req.body;

    const user = await User.findOne({email:email});
    if(!user){
      res.status(404).json({message:"User already exists"});
      return;
    }


    const isMatch = await bcrypt.compare(password,user.password);
    if(!isMatch)
    {
      res.status(400).json({message:"Invalid Credentials"});
      return;
    }

    if(!process.env.JWT_SECRET)
    {
      res.status(500).json({
         message:"authentication error"
      });
      return;
    }
    const token  = jwt.sign({id:user._id},process.env.JWT_SECRET,{
      expiresIn:"1d"
    });
    res.status(200).json({
      token
    })

   } catch (error:any) {
    console.log(error.message);
    res.status(500).json({error: error.message});
   }
}
