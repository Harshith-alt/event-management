import  mongoose  from "mongoose";

const connectDB = async():Promise<void> =>{
   try {
    if(!process.env.MONGODB_URI)
    {
        console.log("DB URL is Missing");
        process.exit(1);
    }
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("MongoDb Connected Successfully");
   } catch (error) {
      console.log("MongoDB Connection failed: ",error);
      process.exit(1);
   }
}
export default connectDB