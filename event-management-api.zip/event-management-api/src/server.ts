import dotenv from 'dotenv'

import express,{Application} from 'express'
import eventRoutes from './routes/events'
import userRoutes from './routes/users'


import morgan from 'morgan'
import connectDB from './config/db';
dotenv.config();
const app:Application = express();

//middleware 
app.use(express.json());
app.use(morgan("tiny"));

//db connect
connectDB();

app.use("/api/events",eventRoutes);
app.use("/api/users",userRoutes);

const PORT  = process.env.PORT ||5000;
app.listen(PORT,()=> console.log(`server running on ${PORT}`))